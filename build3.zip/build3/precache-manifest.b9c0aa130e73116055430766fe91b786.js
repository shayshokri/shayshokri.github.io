self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c188cf6cb244a937e4a3528972afe8c2",
    "url": "/index.html"
  },
  {
    "revision": "91b0439e105d183b9b9f",
    "url": "/static/css/main.91db29ff.chunk.css"
  },
  {
    "revision": "8eddc0e971d76f152d40",
    "url": "/static/js/2.20fd5cb4.chunk.js"
  },
  {
    "revision": "5ac48c47bb3912b14c2d8de4f56d5ae8",
    "url": "/static/js/2.20fd5cb4.chunk.js.LICENSE.txt"
  },
  {
    "revision": "91b0439e105d183b9b9f",
    "url": "/static/js/main.289fc328.chunk.js"
  },
  {
    "revision": "2060b9a7e54a59ab7b07",
    "url": "/static/js/runtime-main.f3a02c50.js"
  },
  {
    "revision": "78580206dc9096cb9de7004ce32bd92e",
    "url": "/static/media/bocconi.78580206.jpg"
  },
  {
    "revision": "2bf0c6650a8bcc81d2af3359eb11d9ff",
    "url": "/static/media/dorm2.2bf0c665.jpg"
  },
  {
    "revision": "bb419774f82e58543de801329568622b",
    "url": "/static/media/favicon.bb419774.ico"
  },
  {
    "revision": "56fdd480b85b7e09f15f8a658aa6f281",
    "url": "/static/media/job.56fdd480.jpg"
  },
  {
    "revision": "523915e491f7ac88f58d9176a832a8ec",
    "url": "/static/media/polimi.523915e4.jpg"
  },
  {
    "revision": "826fc0c1324f91382df64efcdb8d0cbe",
    "url": "/static/media/scholarship.826fc0c1.jpg"
  },
  {
    "revision": "ef81dc7fb233610b303cb6045e0ea372",
    "url": "/static/media/unimi.ef81dc7f.jpg"
  }
]);